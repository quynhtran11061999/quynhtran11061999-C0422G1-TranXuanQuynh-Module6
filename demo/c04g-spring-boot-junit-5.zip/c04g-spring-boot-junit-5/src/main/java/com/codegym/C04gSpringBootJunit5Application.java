package com.codegym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C04gSpringBootJunit5Application {

    public static void main(String[] args) {
        SpringApplication.run(C04gSpringBootJunit5Application.class, args);
    }

}
